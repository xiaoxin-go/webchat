export default {
  name: null,
  setName(newName){
    this.name = newName;
  }
}
